// Password yang sudah di-encode dengan Base64
const correctPasswordEncoded = "em9uYWdhbnRlbmcx"; // "

function openLoginModal(url) {
    const modal = document.getElementById("login-modal");
    modal.style.display = "block";
    // Simpan URL tujuan
    modal.dataset.url = url;
}

function closeModal() {
    const modal = document.getElementById("login-modal");
    modal.style.display = "none";
}

function login() {
    const password = document.getElementById("password").value;
    const errorDiv = document.getElementById("error");
    const modal = document.getElementById("login-modal");
    const targetUrl = modal.dataset.url;

    // Encode password yang dimasukkan user ke base64
    const encodedInput = btoa(password); // btoa() untuk encode ke base64

    // Cek apakah password yang di-input user sesuai dengan yang ter-encode
    if (encodedInput === correctPasswordEncoded) {
        window.location.href = targetUrl; // Arahkan ke URL yang sesuai setelah login berhasil
    } else {
        errorDiv.innerHTML = "Password salah!"; // Tampilkan pesan error jika password salah
    }
}
